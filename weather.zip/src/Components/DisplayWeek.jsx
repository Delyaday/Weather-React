import React from 'react';

import API from '../API';

class DisplayWeek extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            weatherData: null
        };
    }
    async componentDidMount() {
        const zip = this.props.zip;

        try {
            let response = await API.get('/forecast/daily', { params: { q: zip, cnt: 5 } });

            this.setState({ weatherData: response.data });
        } catch (ex) {
            alert(ex.toString());
        }
    }
    
    render() {
        const weatherData = this.state.weatherData;
        if (!weatherData) return <div className="loading"></div>
        if (!weatherData.list) return <div> No data found</div>;
        return (
            <div className="weather-week">
                {
                    weatherData.list.map(weather => <Weather weather={weather} />)
                }
            </div>
        );
    }
}

function Weather(props) {
    const weather = props.weather;
    let date = new Date(weather.dt * 1000);
    let dateString = date.getDate().toString().padStart(2, '0') + "." + (date.getMonth() + 1).toString().padStart(2, '0') + "." + date.getFullYear();
    return (
        <div className="weather-week-item">
            <span className="label">{weather.weather[0].main}</span>
            <span className="temp">{weather.temp.day.toFixed(0)}°C</span>
            <span className="date">{dateString}</span>
        </div>
    )
}

export default DisplayWeek;