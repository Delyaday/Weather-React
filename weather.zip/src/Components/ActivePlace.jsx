import React from 'react';

class ActivePlace extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            activePlace: 0
        }
        this.places = props.places;

        this.selectPlace = props.selectPlace;
    }

    render() {
        return (
            <div className="active-places">
                {this.places.map((place, index) =>
                    <span
                        className={"place " + ((this.state.activePlace == index) ? "active" : "")}
                        key={index}
                        onClick={() => {
                            this.setState({ activePlace: index });
                            this.selectPlace(index);
                        }} >
                        {place.name}
                    </span>
                )}
            </div>
        )
    }
}

export default ActivePlace;