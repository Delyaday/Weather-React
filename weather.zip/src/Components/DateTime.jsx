import React from 'react';

function DateTime() {
    let days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    let d = new Date();
    let dayName = days[d.getDay()];
    return (
        <div className="datetime">
            <div className="time">
                {new Date().toLocaleTimeString()}
            </div>
            <div className="date">
                {dayName},
                {new Date().toLocaleDateString()}
            </div>
        </div>
    )
}

export default DateTime;