import React from 'react';

import API from '../API';

class Display extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            weatherData: null
        };
    }
    async componentDidMount() {
        const zip = this.props.zip;

        try {
            let response = await API.get('/weather', { params: { q: zip } });

            this.setState({ weatherData: response.data });
        } catch (ex) {
            alert(ex.toString());
        }
    }
    render() {
        const weatherData = this.state.weatherData;
        if (!weatherData) return <div className="loading"></div>;
        const weather = weatherData.weather[0];
        if (!weatherData.weather) return <div> No data found</div>;
        const iconUrl = "http://openweathermap.org/img/w/" + weather.icon + ".png";
        return (
            <div className="weather-display">
                <h1>
                    {weather.main} in {weatherData.name}
                    <img src={iconUrl} alt={weatherData.description} />
                </h1>
                <p className='current'>{weatherData.main.temp.toFixed(0)}°C</p>
                <p className='wind'>Wind Speed: {weatherData.wind.speed} mi/hr</p>
            </div>
        );
    }
}

export default Display;