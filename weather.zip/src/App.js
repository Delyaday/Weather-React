import React, { Component, Suspense } from "react";

import { Navbar, Container, Row, Col } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import "./App.scss";
import ActivePlace from "./Components/ActivePlace";
import Display from "./Components/Display";
import ErrorBoundary from "./Components/ErrorBoundary";
import DateTime from "./Components/DateTime";
import DisplayWeek from "./Components/DisplayWeek";


const PLACES = [
  { name: "Moscow", zip: "101000" },
  { name: "Kiev", zip: "03141" },
  { name: "Helsinki", zip: "00100" },
  { name: "Seattle", zip: "98101" },
  { name: "Rome", zip: "00061" }
];

class App extends Component {
  constructor() {
    super();
    this.state = {
      activePlace: 0
    }
  }
  render() {
    const activePlace = this.state.activePlace;

    let selectPlace = (index) => {
      this.setState({ activePlace: index });
    }

    return (
      <div className="App">
        <ErrorBoundary>

          <div className="background">
            <img src="https://free4kwallpapers.com/uploads/originals/2019/08/29/sunset-with-mountains-above-clouds-wallpaper.jpg" />
          </div>

          <div className="weather">
            <ActivePlace
              places={PLACES}
              selectPlace={selectPlace}
            />

            <DateTime />

            <Display
              key={activePlace}
              zip={PLACES[activePlace].zip}
            />

            <DisplayWeek
              key={activePlace + 1}
              zip={PLACES[activePlace].zip}
            />
          </div>

        </ErrorBoundary>
      </div>
    );
  }
}

export default App;