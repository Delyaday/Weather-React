import axios from 'axios';

export default axios.create({
    baseURL: 'http://api.openweathermap.org/data/2.5',
    responseType: "json",
    params: { appid: 'b1b35bba8b434a28a0be2a3e1071ae5b', units: 'metric'},
});